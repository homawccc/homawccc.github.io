-- phpMyAdmin SQL Dump
-- version 5.1.0-dev
-- https://www.phpmyadmin.net/
--
-- Host: 192.168.30.22
-- Generation Time: Dec 18, 2019 at 08:55 PM
-- Server version: 10.4.8-MariaDB-1:10.4.8+maria~stretch-log
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `presidents`
--
CREATE DATABASE IF NOT EXISTS `presidents` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `presidents`;

-- --------------------------------------------------------

--
-- Table structure for table `Presidents`
--

DROP TABLE IF EXISTS `Presidents`;
CREATE TABLE `Presidents` (
  `ID` int(2) DEFAULT NULL,
  `President` varchar(10) DEFAULT NULL,
  `FirstName` varchar(14) DEFAULT NULL,
  `YearsInOffice` decimal(3,1) DEFAULT NULL,
  `YearInaugurated` int(4) DEFAULT NULL,
  `AgeInauguration` int(2) DEFAULT NULL,
  `State` varchar(13) DEFAULT NULL,
  `Party` varchar(21) DEFAULT NULL,
  `Occupation` varchar(15) DEFAULT NULL,
  `College` varchar(21) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Presidents`
--

INSERT INTO `Presidents` (`ID`, `President`, `FirstName`, `YearsInOffice`, `YearInaugurated`, `AgeInauguration`, `State`, `Party`, `Occupation`, `College`) VALUES
(1, 'Washington', 'George', '8.0', 1789, 57, 'Virginia', 'None', 'Planter', 'None'),
(2, 'Adams', 'John', '4.0', 1797, 61, 'Massachusetts', 'Federalist', 'Lawyer', 'Harvard'),
(3, 'Jefferson', 'Thomas', '8.0', 1801, 57, 'Virginia', 'Democratic-Republican', 'Planter, Lawyer', 'William and Mary'),
(4, 'Madison', 'James', '8.0', 1809, 57, 'Virginia', 'Democratic-Republican', 'Lawyer', 'Princeton'),
(5, 'Monroe', 'James', '8.0', 1817, 58, 'Virginia', 'Democratic-Republican', 'Lawyer', 'William and Mary'),
(6, 'Adams', 'John Quincy', '4.0', 1825, 57, 'Massachusetts', 'Democratic-Republican', 'Lawyer', 'Harvard'),
(7, 'Jackson', 'Andrew', '8.0', 1829, 61, 'Tennessee', 'Democrat', 'Lawyer', 'None'),
(8, 'Van Buren', 'Martin', '4.0', 1837, 54, 'New York', 'Democrat', 'Lawyer', 'None'),
(9, 'Harrison', 'William Henry', '0.8', 1841, 68, 'Ohio', 'Whig', 'Soldier', 'Hampden-Sydney'),
(10, 'Tyler', 'John', '4.0', 1841, 51, 'Virginia', 'Whig', 'Lawyer', 'William and Mary'),
(11, 'Polk', 'James K.', '4.0', 1845, 49, 'Tennessee', 'Democrat', 'Lawyer', 'U. of North Carolina'),
(12, 'Taylor', 'Zachary', '1.0', 1849, 64, 'Louisiana', 'Whig', 'Soldier', 'None'),
(13, 'Fillmore', 'Millard', '3.0', 1850, 50, 'New York', 'Whig', 'Lawyer', 'None'),
(14, 'Pierce', 'Franklin', '4.0', 1853, 48, 'New Hampshire', 'Democrat', 'Lawyer', 'Bowdoin'),
(15, 'Buchanan', 'James', '4.0', 1857, 65, 'Pennsylvania', 'Democrat', 'Lawyer', 'Dickinson'),
(16, 'Lincoln', 'Abraham', '4.0', 1861, 52, 'Illinois', 'Republican', 'Lawyer', 'None'),
(17, 'Johnson', 'Andrew', '4.0', 1865, 56, 'Tennessee', 'National Union', 'Tailor', 'None'),
(18, 'Grant', 'Ulysses S.', '8.0', 1869, 46, 'Illinois', 'Republican', 'Soldier', 'US Military Academy'),
(19, 'Hayes', 'Rutherford B.', '4.0', 1877, 54, 'Ohio', 'Republican', 'Lawyer', 'Kenyon'),
(20, 'Garfield', 'James A.', '0.5', 1881, 49, 'Ohio', 'Republican', 'Lawyer', 'Williams'),
(21, 'Arthur', 'Chester A.', '3.0', 1881, 50, 'New York', 'Republican', 'Lawyer', 'Union'),
(22, 'Cleveland', 'Grover', '4.0', 1885, 47, 'New York', 'Democrat', 'Lawyer', 'None'),
(23, 'Harrison', 'Benjamin', '4.0', 1889, 55, 'Indiana', 'Republican', 'Lawyer', 'Miami'),
(24, 'Cleveland', 'Grover', '4.0', 1893, 55, 'New York', 'Democrat', 'Lawyer', 'None'),
(25, 'McKinley', 'William', '4.0', 1897, 54, 'Ohio', 'Republican', 'Lawyer', 'Allegheny College'),
(26, 'Roosevelt', 'Theodore', '8.0', 1901, 42, 'New York', 'Republican', 'Author', 'Harvard'),
(27, 'Taft', 'William Howard', '4.0', 1909, 51, 'Ohio', 'Republican', 'Lawyer', 'Yale'),
(28, 'Wilson', 'Woodrow', '8.0', 1913, 56, 'New Jersey', 'Democrat', 'Educator', 'Princeton'),
(29, 'Harding', 'Warren G.', '2.0', 1921, 55, 'Ohio', 'Republican', 'Editor', 'None'),
(30, 'Coolidge', 'Calvin', '6.0', 1923, 51, 'Massachusetts', 'Republican', 'Lawyer', 'Amherst'),
(31, 'Hoover', 'Herbert', '4.0', 1929, 54, 'California', 'Republican', 'Engineer', 'Stanford'),
(32, 'Roosevelt', 'Franklin', '12.0', 1933, 51, 'New York', 'Democrat', 'Lawyer', 'Harvard'),
(33, 'Truman', 'Harry S.', '8.0', 1945, 60, 'Missouri', 'Democrat', 'Businessman', 'None'),
(34, 'Eisenhower', 'Dwight D.', '8.0', 1953, 62, 'New York', 'Republican', 'Soldier', 'US Military Academy'),
(35, 'Kennedy', 'John F.', '3.0', 1961, 43, 'Massachusetts', 'Democrat', 'Author', 'Harvard'),
(36, 'Johnson', 'Lyndon B.', '5.0', 1963, 55, 'Texas', 'Democrat', 'Teacher', 'Southwest Texas State'),
(37, 'Nixon', 'Richard M.', '5.0', 1969, 56, 'New York', 'Republican', 'Lawyer', 'Whittier'),
(38, 'Ford', 'Gerald', '3.0', 1974, 61, 'Michigan', 'Republican', 'Lawyer', 'Michigan'),
(39, 'Carter', 'Jimmy', '4.0', 1977, 52, 'Georgia', 'Democrat', 'Businessman', 'US Naval Academy'),
(40, 'Reagan', 'Ronald', '8.0', 1981, 69, 'California', 'Republican', 'Actor', 'Eureka College'),
(41, 'Bush', 'George', '4.0', 1989, 64, 'Texas', 'Republican', 'Businessman', 'Yale'),
(42, 'Clinton', 'Bill', '8.0', 1993, 46, 'Arkansas', 'Democrat', 'Lawyer', 'Georgetown'),
(43, 'Bush', 'George W.', '8.0', 2001, 54, 'Texas', 'Republican', 'Businessman', 'Yale'),
(44, 'Obama', 'Barack Hussein', '6.0', 2009, 47, 'Illinois', 'Democrat', 'Lawyer', 'Columbia University');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

ALTER TABLE Democrat ADD Did int NOT NULL AUTO_INCREMENT, PRIMARY KEY (Did);

ALTER TABLE Democrat MODIFY COLUMN Did INT AUTO_INCREMENT;

ALTER TABLE Democrat ADD CONSTRAINT Did AUTO_INCREMENT;

ALTER TABLE Democrat ADD Did int NOT NULL AUTO_INCREMENT

ALTER TABLE Democrat MODIFY Did int NULL;

INSERT INTO Democrat (`President`, `FirstName`, `YearsInOffice`,
 `YearInaugurated`, `AgeInauguration`, `State`, `Party`, `Occupation`, `College`, `PresID`)
SELECT `President`, `FirstName`, `YearsInOffice`,
 `YearInaugurated`, `AgeInauguration`, `State`, `Party`, `Occupation`, `College`, `ID`
FROM Presidents
WHERE Party='Democrat';

ALTER TABLE Democrat ADD column `id` int(10) unsigned primary KEY AUTO_INCREMENT;

ALTER TABLE Democrat
ADD CONSTRAINT PresID NOT NULL;

ALTER TABLE Democrat
ADD FOREIGN KEY(PresID) REFERENCES Presidents(ID)
ON UPDATE SET NULL
ON DELETE SET NULL;

ALTER TABLE Democrat
ADD CONSTRAINT FK_ID FOREIGN KEY(PresID) REFERENCES Presidents(ID);

ALTER TABLE Democrat
DROP COLUMN ID;

ALTER TABLE Presidents
ADD PRIMARY KEY (ID);

DELETE FROM Democrat WHERE PresID='NULL';